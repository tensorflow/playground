Clazz.declarePackage ("JS");
c$ = Clazz.declareType (JS, "SwingConstants");
Clazz.defineStatics (c$,
"LEFT", 2,
"CENTER", 0,
"RIGHT", 4);
